# helloFYBSc
Class REPO
This is the part of our practical based on Github
This is to be included in the new branch we created.
We have a little clue about what we are doing.
